/**
 * Vlist
 */
(function (global, factory) {
    (typeof exports === 'object' && typeof module !== 'undefined') ? module.exports = factory() : (global.Vlist = factory());
}(this, function () {
    function Vlist(param) {
        this.locker = false;//ajax request locker
        this.itemWidth = param.itemWidth;//每一项的高度
        this.itemHeight = param.itemHeight;//每一项的
        this.container = param.container;//容器
        this.containerUL = this.container.querySelector("ul");//容器内的ul
        this.containerWidth = param.containerWidth ? param.containerWidth : document.documentElement.clientWidth;
        this.showItemCount = Math.ceil(this.containerWidth / this.itemWidth) + 1;//视图区域显示item的个数
        this.items = [];//可见列表项
        this.startIndex = 0;//第一个item索引
        this.render = param.render;//渲染每一项的函数
        this.data = [];//列表数据
        //初始化数据
        if (param.initData) {
            this.addData(param.initData);
        }
        if (param.loadData) {
            this.loadData = function () {
                if (this.locker) return;
                this.locker = true;
                param.loadData()
            };
            //如果没有初始化数据就调用拉取数据接口
            if (Array.isArray(param.initData) && param.initData.length == 0) {
                this.loadData();
            }
        }
        this.scrollEventBind = this.scrollEvent.bind(this);
        this.container.addEventListener("scroll", this.scrollEventBind, false);
    }

    Vlist.prototype.renderItem = function (item) {
        var index = item.index;
        var itemDom = item.dom ? item.dom : document.createElement("LI");
        var itemData = this.data[index];
        var left = parseInt(index * this.itemWidth);
        itemDom.innerHTML = this.render(itemData, index);
        itemDom.style.position = "absolute";
        itemDom.style.left = left + "px";
        itemDom.style.top = 0;
        itemDom.style.width = this.itemWidth + "px";
        itemDom.style.height = "100%";
        itemDom.style.overflow = "hidden";
        item.dom = itemDom;
        item.dom.setAttribute("index", index);
        item.left = left;
        return item;
    }

    //第一次初始化列表项
    Vlist.prototype.initList = function () {
        var count = this.data.length < this.showItemCount ? this.data.length : this.showItemCount;
        for (var i = 0; i < count; i++) {
            var item = this.renderItem({
                index: i
            });
            this.containerUL.appendChild(item.dom);
            this.items.push(item);
        }
    }

    Vlist.prototype.destroy = function () {
        this.containerUL.innerHTML = '';
        this.data = [];
        this.items = [];
        this.locker = false;
        this.startIndex = 0;
        this.container.removeEventListener("scroll", this.scrollEventBind, false)
    }

    Vlist.prototype.reloadData = function (data) {
        this.destroy();
        this.addData(data);
    }

    //ajax请求后 添加数据
    Vlist.prototype.addData = function (data) {
        this.locker = false;
        let isInit = this.data.length == 0;
        this.data = this.data.concat(data);
        var realWidth = parseInt(this.data.length * this.itemWidth);
        if (realWidth > this.containerWidth) {
            this.showItemCount = Math.ceil(this.containerWidth / this.itemWidth) + 1;//视图区域显示item的个数
        } else {
            this.showItemCount = this.data.length + 1;//视图区域显示item的个数
        }
        this.containerUL.style.width = realWidth + 'px';
        if (isInit) {
            this.initList();
        }
        this.closeLoading();
    }

    //显示loading
    Vlist.prototype.showLoading = function () {
        if (!this.loadingDom) {
            this.loadingDom = document.createElement("LI");
            this.loadingDom.setAttribute("class", "loading");
            this.loadingDom.innerText = "加载中...";
        }
        this.loadingDom.style.position = "absolute";
        this.loadingDom.style.left = (this.items[this.items.length - 1].left + this.itemWidth) + 'px';
        this.containerUL.appendChild(this.loadingDom);
    }

    //关闭loading
    Vlist.prototype.closeLoading = function () {
        if (this.loadingDom)
            this.containerUL.removeChild(this.loadingDom);
    }

    Vlist.prototype.diffRender = function (startIndex, startIndexNew) {
        var showItemCount = this.showItemCount;
        var items = this.items;
        var moveCount = Math.abs(startIndex - startIndexNew);
        if (moveCount >= showItemCount) {
            //全部渲染
            items.forEach((item, idx) => {
                item.index = startIndexNew + idx;
                this.renderItem(item);
            })
        } else {
            //部分渲染
            if (startIndex - startIndexNew > 0) {
                //逆 下拉
                for (var i = 1; i <= moveCount; i++) {
                    var item = items[showItemCount - i];
                    item.index = item.index - showItemCount;
                    this.renderItem(item);
                }
                this.items = items.splice(showItemCount - moveCount, moveCount).concat(items);
            } else {
                for (var i = 0; i < moveCount; i++) {
                    var item = items[i];
                    item.index = item.index + showItemCount;
                    this.renderItem(item);
                }
                this.items = items.concat(items.splice(0, moveCount));
            }
        }
    }

    //滚动事件
    Vlist.prototype.scrollEvent = function () {
        var containerScrollLeft = this.container.scrollLeft;
        var itemWidth = this.itemWidth;
        var startIndex = this.startIndex;
        if (containerScrollLeft < 0) return;//ios兼容
        var startIndexNew = Math.floor(containerScrollLeft / itemWidth);
        var maxStartIndex = this.data.length - this.showItemCount + 1;
        //android手机兼容性问题
        startIndexNew = startIndexNew > maxStartIndex ? maxStartIndex : startIndexNew;
        if (startIndexNew === startIndex) return;
        var scrollOver = startIndexNew + this.showItemCount - 1 >= this.data.length;
        var renderOver = startIndexNew - startIndex === 1;
        if (scrollOver && renderOver) {
            //到底了
            if (this.loadData) {
                this.showLoading();
                this.loadData();
            }
            return;
        }
        //如果到底没有渲染完就再渲染一次
        if (scrollOver && renderOver === false) {
            startIndexNew--;
        }
        this.diffRender(startIndex, startIndexNew);
        this.startIndex = startIndexNew;
    }
    return Vlist;
}))