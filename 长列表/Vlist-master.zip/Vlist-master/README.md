# Vlist
vitural list Infinite Scrolling 虚拟列表，无限滚动，高性能列表

## 特点
高性能，可支持超长列表滚动

## 原理
只渲染可视范围内的dom,通过复用超出可视范围的dom达到提高性能的目的

## 支持环境和框架
支持原生js开发以及react和vue框架

## 效果
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190215141430134.gif)

## 使用方法
详见demo h5-demo已适配